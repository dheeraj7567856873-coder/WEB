# Wealthly API — REST reference

Base URL: `http://localhost:5000/api/v1`

All authenticated endpoints require:

```
Authorization: Bearer <accessToken>
```

Every record is scoped to the authenticated user; there is no endpoint that can
read another user's data.

Error shape:

```json
{ "success": false, "message": "Amount must be greater than zero", "errors": [{ "field": "amount", "message": "..." }] }
```

## Auth

| Method | Path | Auth | Body |
| --- | --- | --- | --- |
| POST | `/auth/register` | – | `{ name, email, password }` |
| POST | `/auth/login` | – | `{ email, password }` |
| POST | `/auth/refresh` | – | `{ refreshToken }` |
| POST | `/auth/logout` | yes | – |
| GET | `/auth/me` | yes | – |
| POST | `/auth/forgot-password` | – | `{ email }` |
| POST | `/auth/reset-password` | – | `{ token, password }` |
| POST | `/auth/change-password` | yes | `{ currentPassword, newPassword }` |

`register`, `login`, `reset-password` and `change-password` return
`{ success, user, accessToken, refreshToken }`.

## Expenses and Incomes

Identical surfaces at `/expenses` and `/incomes`.

| Method | Path | Notes |
| --- | --- | --- |
| GET | `/expenses?from=&to=&category=&page=&limit=` | paginated, newest first |
| POST | `/expenses` | `{ date: "YYYY-MM-DD", category, amount, note? }` |
| GET | `/expenses/:id` | single record |
| PATCH/PUT | `/expenses/:id` | partial update |
| DELETE | `/expenses/:id` | remove |

## Budgets

| Method | Path | Body |
| --- | --- | --- |
| GET | `/budgets` | – |
| PUT/POST | `/budgets` | `{ month: "YYYY-MM", amount }` (upsert) |
| DELETE | `/budgets/:month` | – |

## Profile

| Method | Path | Body |
| --- | --- | --- |
| GET | `/profile` | – |
| PATCH/PUT | `/profile` | `{ name?, currency?, theme? }` |
| POST | `/profile/avatar` | `multipart/form-data`, field `avatar` (image, max 2 MB) |

## Reports, export and import

| Method | Path | Notes |
| --- | --- | --- |
| GET | `/reports/summary?from=&to=` | totals, per-category split, monthly trend, budgets |
| GET | `/reports/export/pdf?from=&to=` | streams `application/pdf` |
| GET | `/reports/export/excel?from=&to=` | streams `.xlsx` (Expenses / Incomes / Budgets sheets) |
| POST | `/reports/import/excel` | `multipart/form-data`, field `file` (`.xlsx`, max 10 MB) |

Import accepts the same workbook the export produces: sheets named
`Expenses`, `Incomes` and `Budgets`, with header rows
`Date, Category, Amount, Note` and `Month, Amount`.

## Health

`GET /api/v1/health` → `{ success: true, status: "ok", uptime }`

## Rate limits

| Scope | Window | Limit |
| --- | --- | --- |
| All API routes | 15 min | 1000 requests / IP |
| Login, register | 15 min | 20 failed attempts / IP |
| Forgot / reset password | 60 min | 5 requests / IP |
| Reports, export, import | 15 min | 60 requests / IP |
