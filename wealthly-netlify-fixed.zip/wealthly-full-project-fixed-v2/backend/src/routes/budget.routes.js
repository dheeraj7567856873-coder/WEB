"use strict";

const express = require("express");
const controller = require("../controllers/budget.controller");
const { budgetValidators } = require("../validators");
const { validate } = require("../middleware/validate");

const router = express.Router();

router.get("/", controller.list);
router.put("/", budgetValidators.upsert, validate, controller.upsert);
router.post("/", budgetValidators.upsert, validate, controller.upsert);
router.delete("/:month", budgetValidators.remove, validate, controller.remove);

module.exports = router;
