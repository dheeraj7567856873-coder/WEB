"use strict";

const express = require("express");
const controller = require("../controllers/report.controller");
const { reportValidators } = require("../validators");
const { validate } = require("../middleware/validate");
const { uploadWorkbook } = require("../middleware/upload");
const { heavyLimiter } = require("../middleware/rateLimit");

const router = express.Router();

router.get("/summary", reportValidators.range, validate, controller.summary);
router.get("/export/pdf", heavyLimiter, reportValidators.range, validate, controller.exportPdf);
router.get("/export/excel", heavyLimiter, reportValidators.range, validate, controller.exportExcel);
router.post("/import/excel", heavyLimiter, uploadWorkbook, controller.importExcel);

module.exports = router;
