"use strict";

const express = require("express");
const controller = require("../controllers/auth.controller");
const { authValidators } = require("../validators");
const { validate } = require("../middleware/validate");
const { requireAuth } = require("../middleware/auth");
const { authLimiter, passwordResetLimiter } = require("../middleware/rateLimit");

const router = express.Router();

router.post("/register", authLimiter, authValidators.register, validate, controller.register);
router.post("/login", authLimiter, authValidators.login, validate, controller.login);
router.post("/refresh", authValidators.refresh, validate, controller.refresh);
router.post("/logout", requireAuth, controller.logout);
router.get("/me", requireAuth, controller.me);

router.post(
  "/forgot-password",
  passwordResetLimiter,
  authValidators.forgotPassword,
  validate,
  controller.forgotPassword,
);
router.post(
  "/reset-password",
  passwordResetLimiter,
  authValidators.resetPassword,
  validate,
  controller.resetPassword,
);
router.post(
  "/change-password",
  requireAuth,
  authValidators.changePassword,
  validate,
  controller.changePassword,
);

module.exports = router;
