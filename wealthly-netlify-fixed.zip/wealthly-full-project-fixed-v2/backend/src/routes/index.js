"use strict";

const express = require("express");
const { requireAuth } = require("../middleware/auth");
const transactionRoutes = require("./transaction.routes");
const expenseController = require("../controllers/expense.controller");
const incomeController = require("../controllers/income.controller");

const router = express.Router();

router.get("/health", (_req, res) => res.json({ success: true, status: "ok", uptime: process.uptime() }));

router.use("/auth", require("./auth.routes"));

// Everything below requires a valid access token and is scoped to that user.
router.use("/expenses", requireAuth, transactionRoutes(expenseController));
router.use("/incomes", requireAuth, transactionRoutes(incomeController));
router.use("/budgets", requireAuth, require("./budget.routes"));
router.use("/profile", requireAuth, require("./profile.routes"));
router.use("/reports", requireAuth, require("./report.routes"));

module.exports = router;
