"use strict";

const express = require("express");
const { transactionValidators } = require("../validators");
const { validate } = require("../middleware/validate");

/** Shared REST surface for /expenses and /incomes. */
module.exports = function transactionRoutes(controller) {
  const router = express.Router();

  router.get("/", transactionValidators.list, validate, controller.list);
  router.post("/", transactionValidators.create, validate, controller.create);
  router.get("/:id", transactionValidators.remove, validate, controller.getOne);
  router.patch("/:id", transactionValidators.update, validate, controller.update);
  router.put("/:id", transactionValidators.update, validate, controller.update);
  router.delete("/:id", transactionValidators.remove, validate, controller.remove);

  return router;
};
