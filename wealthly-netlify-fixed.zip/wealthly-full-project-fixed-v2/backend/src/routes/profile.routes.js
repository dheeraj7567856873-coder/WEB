"use strict";

const express = require("express");
const controller = require("../controllers/profile.controller");
const { profileValidators } = require("../validators");
const { validate } = require("../middleware/validate");
const { uploadAvatar } = require("../middleware/upload");

const router = express.Router();

router.get("/", controller.get);
router.patch("/", profileValidators.update, validate, controller.update);
router.put("/", profileValidators.update, validate, controller.update);
router.post("/avatar", uploadAvatar, controller.uploadAvatar);

module.exports = router;
