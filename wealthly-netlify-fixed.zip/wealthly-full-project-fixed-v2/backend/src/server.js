"use strict";

require("dotenv").config();

const { loadConfig } = require("./config");
const { connectDatabase, disconnectDatabase } = require("./config/db");
const { createApp } = require("./app");
const logger = require("./utils/logger");

async function start() {
  const config = loadConfig();
  await connectDatabase();

  const app = createApp(config);
  const server = app.listen(config.port, () =>
    logger.info(`Wealthly API listening on port ${config.port} (${config.env})`),
  );

  const shutdown = async (signal) => {
    logger.info(`${signal} received — shutting down`);
    server.close(async () => {
      await disconnectDatabase();
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10000).unref();
  };

  ["SIGTERM", "SIGINT"].forEach((signal) => process.on(signal, () => shutdown(signal)));
  process.on("unhandledRejection", (reason) => logger.error("Unhandled rejection", reason));
  process.on("uncaughtException", (error) => {
    logger.error("Uncaught exception", error);
    process.exit(1);
  });
}

start().catch((error) => {
  logger.error("Failed to start server", error);
  process.exit(1);
});
