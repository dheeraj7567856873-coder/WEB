"use strict";

const { body, param, query } = require("express-validator");

const email = () =>
  body("email").trim().isEmail().withMessage("Enter a valid email address").normalizeEmail().isLength({ max: 255 });

const password = (field = "password") =>
  body(field)
    .isString()
    .isLength({ min: 8, max: 128 })
    .withMessage("Password must be between 8 and 128 characters");

const authValidators = {
  register: [
    body("name").trim().notEmpty().withMessage("Name is required").isLength({ max: 80 }),
    email(),
    password(),
  ],
  login: [email(), body("password").isString().notEmpty().withMessage("Password is required")],
  forgotPassword: [email()],
  resetPassword: [
    body("token").isString().isLength({ min: 20, max: 200 }).withMessage("Invalid reset token"),
    password(),
  ],
  changePassword: [
    body("currentPassword").isString().notEmpty().withMessage("Current password is required"),
    password("newPassword"),
  ],
  refresh: [body("refreshToken").optional().isString()],
};

const profileValidators = {
  update: [
    body("name").optional().trim().notEmpty().isLength({ max: 80 }),
    body("currency").optional().trim().isLength({ max: 8 }),
    body("theme").optional().trim().isLength({ max: 24 }),
  ],
};

const transactionValidators = {
  create: [
    body("date").matches(/^\d{4}-\d{2}-\d{2}$/).withMessage("Date must be YYYY-MM-DD"),
    body("category").trim().notEmpty().withMessage("Category is required").isLength({ max: 60 }),
    body("amount").isFloat({ gt: 0 }).withMessage("Amount must be greater than zero"),
    body("note").optional({ values: "falsy" }).trim().isLength({ max: 240 }),
  ],
  update: [
    param("id").isMongoId().withMessage("Invalid id"),
    body("date").optional().matches(/^\d{4}-\d{2}-\d{2}$/),
    body("category").optional().trim().notEmpty().isLength({ max: 60 }),
    body("amount").optional().isFloat({ gt: 0 }),
    body("note").optional({ values: "falsy" }).trim().isLength({ max: 240 }),
  ],
  remove: [param("id").isMongoId().withMessage("Invalid id")],
  list: [
    query("from").optional().matches(/^\d{4}-\d{2}-\d{2}$/),
    query("to").optional().matches(/^\d{4}-\d{2}-\d{2}$/),
    query("category").optional().trim().isLength({ max: 60 }),
    query("page").optional().isInt({ min: 1 }),
    query("limit").optional().isInt({ min: 1, max: 500 }),
  ],
};

const budgetValidators = {
  upsert: [
    body("month").matches(/^\d{4}-\d{2}$/).withMessage("Month must be YYYY-MM"),
    body("amount").isFloat({ min: 0 }).withMessage("Budget cannot be negative"),
  ],
  remove: [param("month").matches(/^\d{4}-\d{2}$/).withMessage("Month must be YYYY-MM")],
};

const reportValidators = {
  range: [
    query("from").optional().matches(/^\d{4}-\d{2}-\d{2}$/),
    query("to").optional().matches(/^\d{4}-\d{2}-\d{2}$/),
  ],
};

module.exports = {
  authValidators,
  profileValidators,
  transactionValidators,
  budgetValidators,
  reportValidators,
};
