"use strict";

/** Central runtime configuration, validated once at boot. */
const required = ["MONGO_URI", "JWT_ACCESS_SECRET", "JWT_REFRESH_SECRET"];

function loadConfig() {
  const missing = required.filter((key) => !process.env[key]);
  if (missing.length) {
    throw new Error(`Missing required environment variables: ${missing.join(", ")}`);
  }

  return {
    env: process.env.NODE_ENV || "development",
    port: Number(process.env.PORT || 5000),
    clientUrl: process.env.CLIENT_URL || "http://localhost:5173",
    clientOrigins: (process.env.CLIENT_ORIGINS || process.env.CLIENT_URL || "")
      .split(",")
      .map((origin) => origin.trim())
      .filter(Boolean),
    jwt: {
      accessSecret: process.env.JWT_ACCESS_SECRET,
      refreshSecret: process.env.JWT_REFRESH_SECRET,
      accessExpires: process.env.JWT_ACCESS_EXPIRES || "15m",
      refreshExpires: process.env.JWT_REFRESH_EXPIRES || "30d",
    },
    bcryptRounds: Number(process.env.BCRYPT_SALT_ROUNDS || 12),
    uploadDir: process.env.UPLOAD_DIR || "uploads",
    maxUploadBytes: Number(process.env.MAX_UPLOAD_BYTES || 2 * 1024 * 1024),
    smtp: {
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: String(process.env.SMTP_SECURE || "false") === "true",
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
      from: process.env.MAIL_FROM || "Wealthly <no-reply@example.com>",
    },
  };
}

module.exports = { loadConfig };
