"use strict";

const mongoose = require("mongoose");
const logger = require("../utils/logger");

/**
 * Connects to MongoDB Atlas with pooling tuned for a multi-instance deployment.
 * Mongoose buffers commands until the connection is ready, so callers do not
 * need to await this before defining models.
 */
async function connectDatabase() {
  const uri = process.env.MONGO_URI;
  if (!uri) throw new Error("MONGO_URI is not set");

  mongoose.set("strictQuery", true);

  mongoose.connection.on("connected", () => logger.info("MongoDB connected"));
  mongoose.connection.on("error", (err) => logger.error("MongoDB error", err));
  mongoose.connection.on("disconnected", () => logger.warn("MongoDB disconnected"));

  await mongoose.connect(uri, {
    maxPoolSize: Number(process.env.MONGO_POOL_SIZE || 20),
    minPoolSize: 2,
    serverSelectionTimeoutMS: 10000,
    socketTimeoutMS: 45000,
    autoIndex: process.env.NODE_ENV !== "production",
  });

  return mongoose.connection;
}

async function disconnectDatabase() {
  await mongoose.connection.close();
}

module.exports = { connectDatabase, disconnectDatabase };
