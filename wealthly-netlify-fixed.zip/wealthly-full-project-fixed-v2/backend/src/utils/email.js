"use strict";

const nodemailer = require("nodemailer");
const logger = require("./logger");

let transporter = null;

function getTransporter() {
  if (transporter) return transporter;
  if (!process.env.SMTP_HOST) return null;

  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE || "false") === "true",
    auth: process.env.SMTP_USER
      ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
      : undefined,
  });
  return transporter;
}

/**
 * Sends an email. When SMTP is not configured the message is logged instead so
 * local development never blocks on mail delivery.
 */
async function sendMail({ to, subject, html, text }) {
  const tx = getTransporter();
  if (!tx) {
    logger.warn("SMTP not configured — email not sent", { to, subject, text });
    return { queued: false };
  }
  await tx.sendMail({
    from: process.env.MAIL_FROM || "Wealthly <no-reply@example.com>",
    to,
    subject,
    text,
    html,
  });
  return { queued: true };
}

function passwordResetEmail(name, link) {
  return {
    subject: "Reset your Wealthly password",
    text: `Hi ${name}, reset your password here: ${link} (valid for 30 minutes).`,
    html: `<p>Hi ${name},</p>
<p>We received a request to reset your Wealthly password.</p>
<p><a href="${link}">Choose a new password</a> — this link expires in 30 minutes.</p>
<p>If you didn't request this, you can safely ignore the email.</p>`,
  };
}

module.exports = { sendMail, passwordResetEmail };
