"use strict";

const PDFDocument = require("pdfkit");

const money = (value, currency) => `${currency} ${Number(value || 0).toFixed(2)}`;

/**
 * Streams a transactions report as a PDF straight to the HTTP response.
 * @param {import('express').Response} res
 */
function streamTransactionsPdf(res, { user, expenses, incomes, range, currency = "$" }) {
  const doc = new PDFDocument({ size: "A4", margin: 42 });

  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", 'attachment; filename="wealthly-report.pdf"');
  doc.pipe(res);

  doc.fontSize(20).text("Wealthly — Financial Report", { align: "left" });
  doc.moveDown(0.3);
  doc.fontSize(10).fillColor("#666")
    .text(`${user.name} · ${user.email}`)
    .text(`Period: ${range.from || "all time"} → ${range.to || "today"}`)
    .text(`Generated: ${new Date().toLocaleString()}`);
  doc.moveDown(1);

  const totalIncome = incomes.reduce((sum, row) => sum + row.amount, 0);
  const totalExpense = expenses.reduce((sum, row) => sum + row.amount, 0);

  doc.fillColor("#000").fontSize(12).text("Summary");
  doc.fontSize(10).fillColor("#333")
    .text(`Total income:  ${money(totalIncome, currency)}`)
    .text(`Total expense: ${money(totalExpense, currency)}`)
    .text(`Net balance:   ${money(totalIncome - totalExpense, currency)}`);
  doc.moveDown(1);

  const section = (title, rows) => {
    doc.fillColor("#000").fontSize(12).text(title);
    doc.moveDown(0.3);
    if (!rows.length) {
      doc.fontSize(10).fillColor("#888").text("No records in this period.");
      doc.moveDown(0.8);
      return;
    }
    rows.forEach((row) => {
      if (doc.y > 760) doc.addPage();
      doc.fontSize(10).fillColor("#333").text(
        `${row.date}   ${String(row.category || "—").padEnd(16)}   ${money(row.amount, currency)}   ${row.note || ""}`,
      );
    });
    doc.moveDown(0.8);
  };

  section("Income", incomes);
  section("Expenses", expenses);

  doc.end();
}

module.exports = { streamTransactionsPdf };
