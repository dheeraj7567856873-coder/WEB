"use strict";

const levels = { error: 0, warn: 1, info: 2, debug: 3 };
const active = levels[process.env.LOG_LEVEL] ?? levels.info;

function emit(level, args) {
  if (levels[level] > active) return;
  const line = { level, time: new Date().toISOString() };
  // eslint-disable-next-line no-console
  console[level === "debug" ? "log" : level](JSON.stringify(line), ...args);
}

module.exports = {
  error: (...args) => emit("error", args),
  warn: (...args) => emit("warn", args),
  info: (...args) => emit("info", args),
  debug: (...args) => emit("debug", args),
};
