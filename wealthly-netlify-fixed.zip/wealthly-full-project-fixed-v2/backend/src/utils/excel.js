"use strict";

const ExcelJS = require("exceljs");
const ApiError = require("./ApiError");

/** Builds an .xlsx workbook with Expenses / Incomes / Budgets sheets. */
async function buildWorkbook({ expenses, incomes, budgets }) {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Wealthly";
  workbook.created = new Date();

  const expenseSheet = workbook.addWorksheet("Expenses");
  expenseSheet.columns = [
    { header: "Date", key: "date", width: 14 },
    { header: "Category", key: "category", width: 20 },
    { header: "Amount", key: "amount", width: 14 },
    { header: "Note", key: "note", width: 40 },
  ];
  expenses.forEach((row) =>
    expenseSheet.addRow({ date: row.date, category: row.category, amount: row.amount, note: row.note }),
  );

  const incomeSheet = workbook.addWorksheet("Incomes");
  incomeSheet.columns = expenseSheet.columns.map((column) => ({ ...column }));
  incomes.forEach((row) =>
    incomeSheet.addRow({ date: row.date, category: row.category, amount: row.amount, note: row.note }),
  );

  const budgetSheet = workbook.addWorksheet("Budgets");
  budgetSheet.columns = [
    { header: "Month", key: "month", width: 14 },
    { header: "Amount", key: "amount", width: 14 },
  ];
  budgets.forEach((row) => budgetSheet.addRow({ month: row.month, amount: row.amount }));

  [expenseSheet, incomeSheet, budgetSheet].forEach((sheet) => {
    sheet.getRow(1).font = { bold: true };
    sheet.views = [{ state: "frozen", ySplit: 1 }];
  });

  return workbook;
}

const HEADER_ALIASES = {
  date: ["date", "day", "on"],
  category: ["category", "type", "tag"],
  amount: ["amount", "value", "total"],
  note: ["note", "notes", "description", "memo"],
  month: ["month", "period"],
};

function indexHeaders(row) {
  const map = {};
  row.eachCell((cell, colNumber) => {
    const label = String(cell.value ?? "").trim().toLowerCase();
    for (const [key, aliases] of Object.entries(HEADER_ALIASES)) {
      if (aliases.includes(label)) map[key] = colNumber;
    }
  });
  return map;
}

function normalizeDate(value) {
  if (!value) return null;
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  const text = String(value).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(text)) return text;
  const parsed = new Date(text);
  return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString().slice(0, 10);
}

/** Parses an uploaded workbook buffer into plain records ready for insertion. */
async function parseWorkbook(buffer) {
  const workbook = new ExcelJS.Workbook();
  try {
    await workbook.xlsx.load(buffer);
  } catch {
    throw ApiError.badRequest("That file could not be read as an Excel workbook");
  }

  const readTransactions = (sheetName) => {
    const sheet = workbook.getWorksheet(sheetName);
    if (!sheet) return [];
    const headers = indexHeaders(sheet.getRow(1));
    if (!headers.date || !headers.amount) return [];

    const rows = [];
    sheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return;
      const date = normalizeDate(row.getCell(headers.date).value);
      const amount = Number(row.getCell(headers.amount).value);
      if (!date || !Number.isFinite(amount) || amount <= 0) return;
      rows.push({
        date,
        amount,
        category: headers.category
          ? String(row.getCell(headers.category).value ?? "Other").trim().slice(0, 60)
          : "Other",
        note: headers.note ? String(row.getCell(headers.note).value ?? "").trim().slice(0, 240) : "",
      });
    });
    return rows;
  };

  const budgetSheet = workbook.getWorksheet("Budgets");
  const budgets = [];
  if (budgetSheet) {
    const headers = indexHeaders(budgetSheet.getRow(1));
    budgetSheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1 || !headers.month || !headers.amount) return;
      const month = String(row.getCell(headers.month).value ?? "").trim();
      const amount = Number(row.getCell(headers.amount).value);
      if (!/^\d{4}-\d{2}$/.test(month) || !Number.isFinite(amount) || amount < 0) return;
      budgets.push({ month, amount });
    });
  }

  return {
    expenses: readTransactions("Expenses"),
    incomes: readTransactions("Incomes"),
    budgets,
  };
}

module.exports = { buildWorkbook, parseWorkbook };
