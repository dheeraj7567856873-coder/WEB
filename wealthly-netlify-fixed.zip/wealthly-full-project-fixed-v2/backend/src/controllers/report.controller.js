"use strict";

const { Expense, Income, Budget } = require("../models");
const ApiError = require("../utils/ApiError");
const asyncHandler = require("../utils/asyncHandler");
const { streamTransactionsPdf } = require("../utils/pdf");
const { buildWorkbook, parseWorkbook } = require("../utils/excel");

function rangeFilter(userId, { from, to }) {
  const filter = { user: userId };
  if (from || to) {
    filter.date = {};
    if (from) filter.date.$gte = from;
    if (to) filter.date.$lte = to;
  }
  return filter;
}

async function loadRange(userId, range) {
  const filter = rangeFilter(userId, range);
  const [expenses, incomes, budgets] = await Promise.all([
    Expense.find(filter).sort({ date: 1 }).lean(),
    Income.find(filter).sort({ date: 1 }).lean(),
    Budget.find({ user: userId }).sort({ month: 1 }).lean(),
  ]);
  return { expenses, incomes, budgets };
}

/** GET /api/v1/reports/summary — totals, category splits and monthly trend. */
const summary = asyncHandler(async (req, res) => {
  const { expenses, incomes, budgets } = await loadRange(req.user._id, req.query);

  const totalExpense = expenses.reduce((sum, row) => sum + row.amount, 0);
  const totalIncome = incomes.reduce((sum, row) => sum + row.amount, 0);

  const byCategory = {};
  expenses.forEach((row) => {
    byCategory[row.category] = (byCategory[row.category] || 0) + row.amount;
  });

  const monthly = {};
  const bucket = (month) => (monthly[month] ||= { month, income: 0, expense: 0 });
  expenses.forEach((row) => (bucket(row.date.slice(0, 7)).expense += row.amount));
  incomes.forEach((row) => (bucket(row.date.slice(0, 7)).income += row.amount));

  return res.json({
    success: true,
    totals: { income: totalIncome, expense: totalExpense, balance: totalIncome - totalExpense },
    byCategory,
    monthly: Object.values(monthly).sort((a, b) => a.month.localeCompare(b.month)),
    budgets: budgets.map((row) => ({ month: row.month, amount: row.amount })),
  });
});

/** GET /api/v1/reports/export/pdf */
const exportPdf = asyncHandler(async (req, res) => {
  const { expenses, incomes } = await loadRange(req.user._id, req.query);
  streamTransactionsPdf(res, {
    user: req.user,
    expenses,
    incomes,
    range: { from: req.query.from, to: req.query.to },
    currency: req.user.currency,
  });
});

/** GET /api/v1/reports/export/excel */
const exportExcel = asyncHandler(async (req, res) => {
  const data = await loadRange(req.user._id, req.query);
  const workbook = await buildWorkbook(data);

  res.setHeader(
    "Content-Type",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  );
  res.setHeader("Content-Disposition", 'attachment; filename="wealthly-data.xlsx"');
  await workbook.xlsx.write(res);
  res.end();
});

/** POST /api/v1/reports/import/excel (multipart/form-data, field name: file) */
const importExcel = asyncHandler(async (req, res) => {
  if (!req.file) throw ApiError.badRequest("Choose an .xlsx workbook to import");

  const { expenses, incomes, budgets } = await parseWorkbook(req.file.buffer);
  const userId = req.user._id;

  const [insertedExpenses, insertedIncomes] = await Promise.all([
    expenses.length
      ? Expense.insertMany(expenses.map((row) => ({ ...row, user: userId })), { ordered: false })
      : [],
    incomes.length
      ? Income.insertMany(incomes.map((row) => ({ ...row, user: userId })), { ordered: false })
      : [],
  ]);

  if (budgets.length) {
    await Budget.bulkWrite(
      budgets.map((row) => ({
        updateOne: {
          filter: { user: userId, month: row.month },
          update: { $set: { amount: row.amount } },
          upsert: true,
        },
      })),
    );
  }

  return res.json({
    success: true,
    imported: {
      expenses: insertedExpenses.length,
      incomes: insertedIncomes.length,
      budgets: budgets.length,
    },
  });
});

module.exports = { summary, exportPdf, exportExcel, importExcel };
