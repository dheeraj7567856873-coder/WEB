"use strict";

const { User } = require("../models");
const ApiError = require("../utils/ApiError");
const asyncHandler = require("../utils/asyncHandler");
const { sendMail, passwordResetEmail } = require("../utils/email");
const {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
  createResetToken,
  hashResetToken,
} = require("../utils/token");

const RESET_TTL_MS = 30 * 60 * 1000;

function issueTokens(user) {
  return {
    accessToken: signAccessToken(user),
    refreshToken: signRefreshToken(user, user.tokenVersion),
  };
}

/** POST /api/v1/auth/register */
const register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;

  const existing = await User.findOne({ email });
  if (existing) throw ApiError.conflict("An account with that email already exists");

  const user = await User.create({ name, email, password });
  return res.status(201).json({ success: true, user: user.toPublic(), ...issueTokens(user) });
});

/** POST /api/v1/auth/login */
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email }).select("+password");
  // Same message for unknown email and wrong password — no account enumeration.
  if (!user || !(await user.comparePassword(password))) {
    throw ApiError.unauthorized("Incorrect email or password");
  }

  user.lastLoginAt = new Date();
  await user.save({ validateBeforeSave: false });

  return res.json({ success: true, user: user.toPublic(), ...issueTokens(user) });
});

/** POST /api/v1/auth/refresh */
const refresh = asyncHandler(async (req, res) => {
  const token = req.body.refreshToken || req.cookies?.refreshToken;
  if (!token) throw ApiError.unauthorized("Missing refresh token");

  let payload;
  try {
    payload = verifyRefreshToken(token);
  } catch {
    throw ApiError.unauthorized("Invalid or expired refresh token");
  }

  const user = await User.findById(payload.sub);
  if (!user || user.tokenVersion !== payload.v) {
    throw ApiError.unauthorized("Session is no longer valid");
  }

  return res.json({ success: true, ...issueTokens(user) });
});

/** POST /api/v1/auth/logout — invalidates every refresh token for the account. */
const logout = asyncHandler(async (req, res) => {
  await User.updateOne({ _id: req.user._id }, { $inc: { tokenVersion: 1 } });
  res.clearCookie?.("refreshToken");
  return res.json({ success: true, message: "Signed out" });
});

/** POST /api/v1/auth/forgot-password */
const forgotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;
  const user = await User.findOne({ email });

  // Always answer identically so the endpoint cannot be used to probe emails.
  const genericResponse = {
    success: true,
    message: "If that email has an account, a reset link is on its way.",
  };
  if (!user) return res.json(genericResponse);

  const { raw, hashed } = createResetToken();
  user.passwordResetToken = hashed;
  user.passwordResetExpires = new Date(Date.now() + RESET_TTL_MS);
  await user.save({ validateBeforeSave: false });

  const link = `${process.env.CLIENT_URL}/reset-password?token=${raw}`;
  await sendMail({ to: user.email, ...passwordResetEmail(user.name, link) });

  return res.json(genericResponse);
});

/** POST /api/v1/auth/reset-password */
const resetPassword = asyncHandler(async (req, res) => {
  const { token, password } = req.body;

  const user = await User.findOne({
    passwordResetToken: hashResetToken(token),
    passwordResetExpires: { $gt: new Date() },
  }).select("+password +passwordResetToken +passwordResetExpires");

  if (!user) throw ApiError.badRequest("This reset link is invalid or has expired");

  user.password = password;
  user.passwordResetToken = undefined;
  user.passwordResetExpires = undefined;
  user.tokenVersion += 1; // sign every other device out
  await user.save();

  return res.json({ success: true, user: user.toPublic(), ...issueTokens(user) });
});

/** POST /api/v1/auth/change-password */
const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;

  const user = await User.findById(req.user._id).select("+password");
  if (!(await user.comparePassword(currentPassword))) {
    throw ApiError.unauthorized("Your current password is incorrect");
  }

  user.password = newPassword;
  user.tokenVersion += 1;
  await user.save();

  return res.json({ success: true, message: "Password updated", ...issueTokens(user) });
});

/** GET /api/v1/auth/me */
const me = asyncHandler(async (req, res) => res.json({ success: true, user: req.user.toPublic() }));

module.exports = {
  register,
  login,
  refresh,
  logout,
  forgotPassword,
  resetPassword,
  changePassword,
  me,
};
