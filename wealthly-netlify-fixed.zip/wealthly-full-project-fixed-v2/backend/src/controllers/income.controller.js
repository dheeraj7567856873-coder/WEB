"use strict";

const { Income } = require("../models");
const { createTransactionController } = require("./transaction.factory");

module.exports = createTransactionController(Income);
