"use strict";

const { Budget } = require("../models");
const ApiError = require("../utils/ApiError");
const asyncHandler = require("../utils/asyncHandler");

/** GET /api/v1/budgets */
const list = asyncHandler(async (req, res) => {
  const items = await Budget.find({ user: req.user._id }).sort({ month: -1 }).lean();
  return res.json({
    success: true,
    items: items.map((row) => ({ month: row.month, amount: row.amount })),
  });
});

/** PUT /api/v1/budgets — create or replace the budget for a month. */
const upsert = asyncHandler(async (req, res) => {
  const { month, amount } = req.body;
  const doc = await Budget.findOneAndUpdate(
    { user: req.user._id, month },
    { $set: { amount } },
    { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true },
  ).lean();

  return res.json({ success: true, item: { month: doc.month, amount: doc.amount } });
});

/** DELETE /api/v1/budgets/:month */
const remove = asyncHandler(async (req, res) => {
  const doc = await Budget.findOneAndDelete({ user: req.user._id, month: req.params.month }).lean();
  if (!doc) throw ApiError.notFound("No budget set for that month");
  return res.json({ success: true, message: "Budget removed" });
});

module.exports = { list, upsert, remove };
