"use strict";

const path = require("path");
const asyncHandler = require("../utils/asyncHandler");
const ApiError = require("../utils/ApiError");

/** GET /api/v1/profile */
const get = asyncHandler(async (req, res) => res.json({ success: true, user: req.user.toPublic() }));

/** PATCH /api/v1/profile */
const update = asyncHandler(async (req, res) => {
  ["name", "currency", "theme"].forEach((field) => {
    if (req.body[field] !== undefined) req.user[field] = req.body[field];
  });
  await req.user.save();
  return res.json({ success: true, user: req.user.toPublic() });
});

/** POST /api/v1/profile/avatar (multipart/form-data, field name: avatar) */
const uploadAvatar = asyncHandler(async (req, res) => {
  if (!req.file) throw ApiError.badRequest("Choose an image to upload");

  req.user.avatarUrl = `/uploads/avatars/${path.basename(req.file.filename)}`;
  await req.user.save();

  return res.json({ success: true, user: req.user.toPublic() });
});

module.exports = { get, update, uploadAvatar };
