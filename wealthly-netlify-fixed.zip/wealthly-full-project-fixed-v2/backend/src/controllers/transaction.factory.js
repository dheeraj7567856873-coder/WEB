"use strict";

const ApiError = require("../utils/ApiError");
const asyncHandler = require("../utils/asyncHandler");

/**
 * Builds the CRUD controller shared by expenses and incomes. Every query is
 * scoped to `req.user._id`, so one user can never read or write another's rows.
 */
function createTransactionController(Model) {
  const list = asyncHandler(async (req, res) => {
    const { from, to, category } = req.query;
    const page = Math.max(1, Number(req.query.page || 1));
    const limit = Math.min(500, Math.max(1, Number(req.query.limit || 100)));

    const filter = { user: req.user._id };
    if (from || to) {
      filter.date = {};
      if (from) filter.date.$gte = from;
      if (to) filter.date.$lte = to;
    }
    if (category) filter.category = category;

    const [items, total] = await Promise.all([
      Model.find(filter).sort({ date: -1, createdAt: -1 }).skip((page - 1) * limit).limit(limit).lean(),
      Model.countDocuments(filter),
    ]);

    return res.json({
      success: true,
      items: items.map(serialize),
      pagination: { page, limit, total, pages: Math.ceil(total / limit) || 1 },
    });
  });

  const create = asyncHandler(async (req, res) => {
    const doc = await Model.create({
      user: req.user._id,
      date: req.body.date,
      category: req.body.category,
      amount: req.body.amount,
      note: req.body.note || "",
    });
    return res.status(201).json({ success: true, item: serialize(doc.toObject()) });
  });

  const getOne = asyncHandler(async (req, res) => {
    const doc = await Model.findOne({ _id: req.params.id, user: req.user._id }).lean();
    if (!doc) throw ApiError.notFound("Record not found");
    return res.json({ success: true, item: serialize(doc) });
  });

  const update = asyncHandler(async (req, res) => {
    const updates = {};
    ["date", "category", "amount", "note"].forEach((field) => {
      if (req.body[field] !== undefined) updates[field] = req.body[field];
    });

    const doc = await Model.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { $set: updates },
      { new: true, runValidators: true },
    ).lean();

    if (!doc) throw ApiError.notFound("Record not found");
    return res.json({ success: true, item: serialize(doc) });
  });

  const remove = asyncHandler(async (req, res) => {
    const doc = await Model.findOneAndDelete({ _id: req.params.id, user: req.user._id }).lean();
    if (!doc) throw ApiError.notFound("Record not found");
    return res.json({ success: true, message: "Deleted" });
  });

  return { list, create, getOne, update, remove };
}

function serialize(doc) {
  return {
    id: String(doc._id),
    date: doc.date,
    category: doc.category,
    amount: doc.amount,
    note: doc.note || "",
    createdAt: doc.createdAt,
  };
}

module.exports = { createTransactionController, serialize };
