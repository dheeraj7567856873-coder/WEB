"use strict";

const { Expense } = require("../models");
const { createTransactionController } = require("./transaction.factory");

module.exports = createTransactionController(Expense);
