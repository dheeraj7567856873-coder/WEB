"use strict";

const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const multer = require("multer");
const ApiError = require("../utils/ApiError");

const UPLOAD_DIR = path.resolve(process.cwd(), process.env.UPLOAD_DIR || "uploads");
const AVATAR_DIR = path.join(UPLOAD_DIR, "avatars");
fs.mkdirSync(AVATAR_DIR, { recursive: true });

const IMAGE_TYPES = new Set(["image/png", "image/jpeg", "image/webp", "image/gif"]);
const SHEET_TYPES = new Set([
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/vnd.ms-excel",
  "application/octet-stream",
]);

const avatarStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, AVATAR_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().slice(0, 8) || ".png";
    cb(null, `${req.user._id}-${crypto.randomBytes(8).toString("hex")}${ext}`);
  },
});

/** Single profile image, written to disk (swap for S3/GCS in production). */
const uploadAvatar = multer({
  storage: avatarStorage,
  limits: { fileSize: Number(process.env.MAX_UPLOAD_BYTES || 2 * 1024 * 1024), files: 1 },
  fileFilter: (_req, file, cb) => {
    if (!IMAGE_TYPES.has(file.mimetype)) return cb(ApiError.badRequest("Only image files are allowed"));
    return cb(null, true);
  },
}).single("avatar");

/** Excel import, kept in memory and parsed without ever touching disk. */
const uploadWorkbook = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    if (!SHEET_TYPES.has(file.mimetype) && !/\.xlsx?$/i.test(file.originalname)) {
      return cb(ApiError.badRequest("Upload an .xlsx workbook"));
    }
    return cb(null, true);
  },
}).single("file");

module.exports = { uploadAvatar, uploadWorkbook, UPLOAD_DIR, AVATAR_DIR };
