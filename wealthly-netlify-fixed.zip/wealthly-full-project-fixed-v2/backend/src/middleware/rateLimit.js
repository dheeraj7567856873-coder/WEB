"use strict";

const rateLimit = require("express-rate-limit");

const base = {
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many requests — please slow down and try again later." },
};

/** Broad limiter applied to the whole API surface. */
const apiLimiter = rateLimit({ ...base, windowMs: 15 * 60 * 1000, limit: 1000 });

/** Tight limiter for credential endpoints (login, register, reset). */
const authLimiter = rateLimit({
  ...base,
  windowMs: 15 * 60 * 1000,
  limit: 20,
  skipSuccessfulRequests: true,
});

/** Password-reset requests are throttled per IP to prevent mail flooding. */
const passwordResetLimiter = rateLimit({ ...base, windowMs: 60 * 60 * 1000, limit: 5 });

/** Report generation and imports are heavier, so they get their own budget. */
const heavyLimiter = rateLimit({ ...base, windowMs: 15 * 60 * 1000, limit: 60 });

module.exports = { apiLimiter, authLimiter, passwordResetLimiter, heavyLimiter };
