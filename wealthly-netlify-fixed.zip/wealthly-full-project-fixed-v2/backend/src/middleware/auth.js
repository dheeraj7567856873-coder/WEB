"use strict";

const { User } = require("../models");
const ApiError = require("../utils/ApiError");
const asyncHandler = require("../utils/asyncHandler");
const { verifyAccessToken } = require("../utils/token");

/**
 * Verifies the `Authorization: Bearer <accessToken>` header and attaches the
 * current user to `req.user`. Every data route depends on this — controllers
 * always scope queries by `req.user._id`, which is what keeps user data
 * separate.
 */
const requireAuth = asyncHandler(async (req, _res, next) => {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : null;
  if (!token) throw ApiError.unauthorized("Missing access token");

  let payload;
  try {
    payload = verifyAccessToken(token);
  } catch (error) {
    throw ApiError.unauthorized(
      error.name === "TokenExpiredError" ? "Access token expired" : "Invalid access token",
    );
  }

  const user = await User.findById(payload.sub);
  if (!user) throw ApiError.unauthorized("Account no longer exists");

  req.user = user;
  return next();
});

module.exports = { requireAuth };
