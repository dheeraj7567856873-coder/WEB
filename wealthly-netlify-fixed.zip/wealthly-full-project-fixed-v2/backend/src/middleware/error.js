"use strict";

const multer = require("multer");
const ApiError = require("../utils/ApiError");
const logger = require("../utils/logger");

/** 404 handler for unmatched routes. */
function notFound(req, _res, next) {
  next(ApiError.notFound(`Route ${req.method} ${req.originalUrl} does not exist`));
}

/** Converts any thrown value into a consistent JSON error response. */
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, _next) {
  let error = err;

  if (err instanceof multer.MulterError) {
    error =
      err.code === "LIMIT_FILE_SIZE"
        ? ApiError.tooLarge("That file is too large")
        : ApiError.badRequest(err.message);
  } else if (err.name === "ValidationError") {
    error = ApiError.badRequest(Object.values(err.errors)[0]?.message || "Validation failed");
  } else if (err.name === "CastError") {
    error = ApiError.badRequest("Invalid identifier");
  } else if (err.code === 11000) {
    const field = Object.keys(err.keyValue || {})[0] || "value";
    error = ApiError.conflict(`That ${field} is already in use`);
  } else if (!(err instanceof ApiError)) {
    error = new ApiError(500, "Something went wrong on our side");
    error.isOperational = false;
  }

  if (!error.isOperational || error.statusCode >= 500) {
    logger.error("Unhandled error", { path: req.originalUrl, message: err.message, stack: err.stack });
  }

  const body = { success: false, message: error.message };
  if (error.details) body.errors = error.details;
  if (process.env.NODE_ENV !== "production" && error.statusCode >= 500) body.stack = err.stack;

  return res.status(error.statusCode || 500).json(body);
}

module.exports = { notFound, errorHandler };
