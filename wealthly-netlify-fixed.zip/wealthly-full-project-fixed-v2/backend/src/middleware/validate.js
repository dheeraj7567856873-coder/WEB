"use strict";

const { validationResult } = require("express-validator");
const ApiError = require("../utils/ApiError");

/** Turns express-validator results into a single 400 response. */
function validate(req, _res, next) {
  const result = validationResult(req);
  if (result.isEmpty()) return next();

  const details = result.array().map((issue) => ({
    field: issue.path,
    message: issue.msg,
  }));
  return next(ApiError.badRequest(details[0].message, details));
}

module.exports = { validate };
