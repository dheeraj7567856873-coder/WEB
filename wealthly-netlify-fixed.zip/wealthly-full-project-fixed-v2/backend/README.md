# Wealthly Backend — Node.js + Express + MongoDB Atlas

A production-ready, multi-user REST API for the Wealthly expense tracker:
JWT authentication, per-user data isolation, budgets, reports, PDF/Excel export,
Excel import, profile management and avatar upload.

This folder is completely standalone — it does not import anything from the
frontend and the frontend is not modified by it.

## Stack

Express 4 · Mongoose 8 · JWT (access + refresh) · bcrypt · Helmet · CORS ·
express-validator · express-rate-limit · Multer · ExcelJS · PDFKit · Nodemailer

## Folder structure

```
backend/
  package.json
  .env.example
  README.md
  API.md
  src/
    server.js            # boot, DB connect, graceful shutdown
    app.js               # express app, security middleware, route mounting
    config/
      index.js           # validated runtime config
      db.js              # MongoDB Atlas connection + pooling
    models/              # Mongoose schemas (User, Expense, Income, Budget)
    controllers/         # request handlers (MVC "C")
    routes/              # REST route definitions
    middleware/          # auth, validation, rate limiting, uploads, errors
    utils/               # tokens, email, pdf, excel, errors, logger
    validators/          # express-validator rule sets
```

## Getting started

```bash
cd backend
cp .env.example .env      # then fill in MONGO_URI and the JWT secrets
npm install
npm run dev               # http://localhost:5000/api/v1/health
```

Generate strong secrets with `openssl rand -hex 32` (one for
`JWT_ACCESS_SECRET`, another for `JWT_REFRESH_SECRET`).

### MongoDB Atlas

1. Create a free cluster at cloud.mongodb.com.
2. Add a database user and allow your server's IP (or `0.0.0.0/0` while testing).
3. Copy the connection string into `MONGO_URI`, ending with `/wealthly`.

## How multi-user isolation works

* `requireAuth` verifies the bearer access token and loads the user.
* Every query in every controller includes `{ user: req.user._id }`.
* Reads, updates and deletes filter on both `_id` **and** `user`, so a guessed
  id from another account returns `404`, never someone else's data.
* Compound indexes `{ user, date }` and `{ user, category }` keep those scoped
  queries fast as the collection grows.

## Security

* bcrypt password hashing (12 rounds by default), passwords never selected by default.
* Short-lived access tokens plus rotating refresh tokens with a `tokenVersion`
  counter — changing a password or logging out invalidates every existing session.
* Password reset tokens are random 256-bit values; only their SHA-256 hash is
  stored, and they expire after 30 minutes.
* Identical responses for unknown and known emails on login and forgot-password
  (no account enumeration).
* Helmet, CORS allow-list, HPP, Mongo operator sanitisation, body size limits,
  MIME + size checks on uploads, and layered rate limits.

## Scaling notes

* Stateless — run as many instances behind a load balancer as you need.
* Connection pool size is configurable via `MONGO_POOL_SIZE`.
* `autoIndex` is disabled in production; create indexes as part of deployment.
* Avatars are written to disk by default. For multi-instance deployments swap
  `multer.diskStorage` in `src/middleware/upload.js` for S3/GCS/R2 storage.
* Graceful shutdown on `SIGTERM`/`SIGINT` for zero-downtime rolling deploys.

## Pointing the frontend at this API

The frontend talks to a single data module. Point it at this server by setting
its base URL to `http://localhost:5000/api/v1`, store the returned
`accessToken`, and send it as `Authorization: Bearer <token>` on every request.
Endpoint-by-endpoint details are in [API.md](./API.md).

## Deployment

Works unchanged on Render, Railway, Fly.io, a VPS with PM2, or Docker.
Set every variable from `.env.example` in the host's environment, set
`NODE_ENV=production`, and run `npm start`.
